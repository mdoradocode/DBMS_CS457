import subprocess

subprocess.run("python3 mdorado_pa4.py & python3 mdorado_pa4.py", shell=True)

